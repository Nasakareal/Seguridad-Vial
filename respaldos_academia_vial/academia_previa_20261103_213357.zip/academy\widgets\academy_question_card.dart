import 'package:flutter/material.dart';

import '../models/vial_question.dart';

class AcademyQuestionCard extends StatelessWidget {
  final VialQuestion question;
  final int questionNumber;
  final int? selected;
  final bool revealAnswer;
  final bool isLast;
  final ValueChanged<int> onAnswer;
  final VoidCallback onNext;

  const AcademyQuestionCard({
    super.key,
    required this.question,
    required this.questionNumber,
    required this.selected,
    required this.revealAnswer,
    required this.isLast,
    required this.onAnswer,
    required this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    final style = _styleFor(question.category);
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 720),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [style.color, style.color.withValues(alpha: .72)],
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: style.color.withValues(alpha: .22),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.white.withValues(alpha: .18),
                        foregroundColor: Colors.white,
                        child: Icon(style.icon),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          question.category.toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .7,
                          ),
                        ),
                      ),
                      Text(
                        '#$questionNumber',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Text(
                    question.prompt,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 23,
                      height: 1.22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            for (var index = 0; index < question.options.length; index++)
              _AnswerOption(
                index: index,
                text: question.options[index],
                selected: selected == index,
                correct: revealAnswer && question.correct == index,
                wrong:
                    revealAnswer &&
                    selected == index &&
                    selected != question.correct,
                disabled: selected != null,
                accent: style.color,
                onTap: () => onAnswer(index),
              ),
            if (revealAnswer) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(17),
                decoration: BoxDecoration(
                  color: selected == question.correct
                      ? const Color(0xFFE8F8EE)
                      : const Color(0xFFFFF2E4),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: selected == question.correct
                        ? const Color(0xFF86D5A2)
                        : const Color(0xFFF3BF86),
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      selected == question.correct
                          ? Icons.lightbulb_circle
                          : Icons.tips_and_updates,
                      color: selected == question.correct
                          ? const Color(0xFF15803D)
                          : const Color(0xFFB45309),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            selected == question.correct
                                ? '¡Decisión segura!'
                                : 'Aprende de esta situación',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 5),
                          Text(question.explanation),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: onNext,
                icon: Icon(isLast ? Icons.emoji_events : Icons.arrow_forward),
                label: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  child: Text(isLast ? 'Ver resultado' : 'Siguiente pregunta'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _AnswerOption extends StatelessWidget {
  final int index;
  final String text;
  final bool selected;
  final bool correct;
  final bool wrong;
  final bool disabled;
  final Color accent;
  final VoidCallback onTap;

  const _AnswerOption({
    required this.index,
    required this.text,
    required this.selected,
    required this.correct,
    required this.wrong,
    required this.disabled,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = correct
        ? const Color(0xFF16A34A)
        : wrong
        ? const Color(0xFFDC2626)
        : selected
        ? accent
        : const Color(0xFFB8C5D6);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: correct
            ? const Color(0xFFEAF8EF)
            : wrong
            ? const Color(0xFFFFEEEE)
            : Colors.white,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(17),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              border: Border.all(color: color, width: correct || wrong ? 2 : 1),
              borderRadius: BorderRadius.circular(17),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: color.withValues(alpha: .12),
                  foregroundColor: color,
                  child: Text(
                    String.fromCharCode(65 + index),
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    text,
                    style: const TextStyle(fontSize: 16, height: 1.25),
                  ),
                ),
                if (correct)
                  const Icon(Icons.check_circle, color: Color(0xFF16A34A))
                else if (wrong)
                  const Icon(Icons.cancel, color: Color(0xFFDC2626)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

({IconData icon, Color color}) _styleFor(String category) {
  final normalized = category.toLowerCase();
  if (normalized.contains('señal') || normalized.contains('semáforo')) {
    return (icon: Icons.traffic, color: const Color(0xFFDC2626));
  }
  if (normalized.contains('peat') || normalized.contains('niñez')) {
    return (icon: Icons.directions_walk, color: const Color(0xFF7C3AED));
  }
  if (normalized.contains('moto') || normalized.contains('ciclista')) {
    return (icon: Icons.two_wheeler, color: const Color(0xFFEA580C));
  }
  if (normalized.contains('alcohol') || normalized.contains('distrac')) {
    return (icon: Icons.health_and_safety, color: const Color(0xFFBE123C));
  }
  if (normalized.contains('lluvia') || normalized.contains('distancia')) {
    return (icon: Icons.water_drop, color: const Color(0xFF0369A1));
  }
  if (normalized.contains('emergencia')) {
    return (icon: Icons.emergency, color: const Color(0xFFB91C1C));
  }
  return (icon: Icons.route, color: const Color(0xFF155EEF));
}
