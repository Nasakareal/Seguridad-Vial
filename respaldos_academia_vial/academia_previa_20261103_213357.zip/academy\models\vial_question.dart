enum AcademiaMode { aprender, practicar, simulacro }

/// Una pregunta editable de Academia Vial.
///
/// [correct] es el índice de la opción correcta y comienza en cero.
class VialQuestion {
  final String category;
  final String prompt;
  final List<String> options;
  final int correct;
  final String explanation;

  const VialQuestion(
    this.category,
    this.prompt,
    this.options,
    this.correct,
    this.explanation,
  );
}
