import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../../services/cultura_vial_audio_service.dart';
import '../../services/cultura_vial_progress_service.dart';
import '../content/vial_question_bank.dart';
import '../models/vial_question.dart';
import '../widgets/academy_question_card.dart';

class AcademiaVialScreen extends StatefulWidget {
  final AcademiaMode initialMode;
  const AcademiaVialScreen({
    super.key,
    this.initialMode = AcademiaMode.aprender,
  });

  @override
  State<AcademiaVialScreen> createState() => _AcademiaVialScreenState();
}

class _AcademiaVialScreenState extends State<AcademiaVialScreen> {
  late AcademiaMode _mode;
  late List<VialQuestion> _questions;
  int _index = 0;
  int _correct = 0;
  int? _selected;
  bool _finished = false;
  int _seconds = 25 * 60;
  Timer? _timer;
  bool _audioEntered = false;

  @override
  void initState() {
    super.initState();
    _audioEntered = true;
    unawaited(CulturaVialAudioService.instance.enterModule());
    _mode = widget.initialMode;
    _reset();
  }

  void _reset() {
    _timer?.cancel();
    final shuffled = List<VialQuestion>.of(vialQuestionBank)..shuffle(Random());
    _questions = _mode == AcademiaMode.practicar
        ? shuffled.take(10).toList()
        : shuffled;
    _index = 0;
    _correct = 0;
    _selected = null;
    _finished = false;
    _seconds = 25 * 60;
    if (_mode == AcademiaMode.simulacro) {
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        if (_seconds <= 1) {
          _finish();
        } else {
          setState(() => _seconds--);
        }
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    if (_audioEntered) {
      unawaited(CulturaVialAudioService.instance.exitModule());
    }
    super.dispose();
  }

  void _answer(int value) {
    if (_selected != null || _finished) return;
    unawaited(CulturaVialAudioService.instance.notifyInteraction());
    final isCorrect = value == _questions[_index].correct;
    setState(() {
      _selected = value;
      if (isCorrect) _correct++;
    });
    if (_mode != AcademiaMode.simulacro) {
      unawaited(
        CulturaVialAudioService.instance.playEffect(
          isCorrect ? CulturaVialSound.correct : CulturaVialSound.wrong,
        ),
      );
    }
    if (_mode == AcademiaMode.simulacro) {
      Future<void>.delayed(const Duration(milliseconds: 220), _next);
    }
  }

  void _next() {
    if (!mounted) return;
    if (_index + 1 >= _questions.length) {
      _finish();
      return;
    }
    setState(() {
      _index++;
      _selected = null;
    });
  }

  Future<void> _finish() async {
    _timer?.cancel();
    if (_finished) return;
    _finished = true;
    if (mounted) setState(() {});
    final percent = _questions.isEmpty
        ? 0
        : ((_correct / _questions.length) * 100).round();
    final gameId = switch (_mode) {
      AcademiaMode.aprender => 'academia_aprender',
      AcademiaMode.practicar => 'academia_practicar',
      AcademiaMode.simulacro => 'academia_simulacro',
    };
    await CulturaVialProgressService.instance.recordGame(
      gameId: gameId,
      score: percent * 10,
      stars: percent >= 90
          ? 3
          : percent >= 75
          ? 2
          : 1,
      correct: _correct,
      mistakes: _questions.length - _correct,
    );
  }

  @override
  Widget build(BuildContext context) {
    final labels = {
      AcademiaMode.aprender: 'Aprender',
      AcademiaMode.practicar: 'Practicar',
      AcademiaMode.simulacro: 'Simulacro',
    };
    return Scaffold(
      appBar: AppBar(title: Text(labels[_mode]!)),
      body: _finished
          ? _result()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: LinearProgressIndicator(
                          value: (_index + 1) / _questions.length,
                          minHeight: 9,
                          borderRadius: BorderRadius.circular(9),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '${_index + 1}/${_questions.length}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      if (_mode == AcademiaMode.simulacro) ...[
                        const SizedBox(width: 12),
                        Text(
                          '${_seconds ~/ 60}:${(_seconds % 60).toString().padLeft(2, '0')}',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ],
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(18),
                    child: _questionCard(),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _questionCard() {
    final question = _questions[_index];
    final revealAnswer = _selected != null && _mode != AcademiaMode.simulacro;
    return AcademyQuestionCard(
      question: question,
      questionNumber: _index + 1,
      selected: _selected,
      revealAnswer: revealAnswer,
      isLast: _index + 1 == _questions.length,
      onAnswer: _answer,
      onNext: _next,
    );
  }

  Widget _result() {
    final percent = ((_correct / _questions.length) * 100).round();
    final passed = percent >= 80;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            children: [
              CircleAvatar(
                radius: 48,
                backgroundColor:
                    (passed ? const Color(0xFF16A34A) : const Color(0xFFD97706))
                        .withValues(alpha: .12),
                child: Icon(
                  passed ? Icons.emoji_events : Icons.menu_book,
                  size: 52,
                  color: passed
                      ? const Color(0xFF16A34A)
                      : const Color(0xFFD97706),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                '$percent%',
                style: const TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                '$_correct de ${_questions.length} respuestas correctas',
                style: const TextStyle(fontSize: 17),
              ),
              const SizedBox(height: 12),
              Text(
                passed
                    ? 'Buen trabajo. Sigue practicando para conservar lo aprendido.'
                    : 'Vuelve al modo Aprender y repasa las explicaciones.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () => setState(_reset),
                icon: const Icon(Icons.replay),
                label: const Text('Intentar de nuevo'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Volver al inicio'),
              ),
              const SizedBox(height: 16),
              const Text(
                'Resultado de práctica; no constituye una aprobación oficial.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Color(0xFF66788A)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
